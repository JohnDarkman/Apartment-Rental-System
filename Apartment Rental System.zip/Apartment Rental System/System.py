# NAVENESH_KUMA_A/L_SASEEKUMAR
# TP065194

from datetime import datetime
from time import sleep
now=datetime.today()
all_tenant=[]
all_apartment=[]
all_history=[]
all_admin=[]

##----------------------------------------------------------------------------------------------------------------------------------------------
##Main menu,admin login,and default user.(Interface)
##----------------------------------------------------------------------------------------------------------------------------------------------
def mainmenu():
    print("")
    print("")
    print("<Tenant Management System>".center(80))
    print("="*80)
    while True:
        print("Press".ljust(40).center(80))
        print("[1]-Login".ljust(40).center(80))
        print("[2]-Access without login(View/Search)".ljust(40).center(80))
        print("[3]-Exit the program".ljust(40).center(80))
        usertype = input("                    Enter your choice:")
        if usertype in ["1","2","3"]:
            break
        print("")
        print("{invalid input}".center(80))
        print("")
    if usertype == "1":
        return login()
    elif usertype == "2":
        return default_user()
    elif usertype == "3":
        pass

def login():
    print("")
    print("")
    print("<Login>".center(30,"~"))
    print("="*30)
    name = input("Enter your name:")
    if name=="John":
        if int(all_admin[0][2])>int(all_admin[0][3]):
            if int(all_admin[0][2])<=int(str(now)[11:13]) or int(all_admin[0][3])>int(str(now)[11:13]):
                pass
            else:
                print("Sorry John, you can only access after "+all_admin[0][2]+":00 - "+all_admin[0][3]+":00")
                print("Current time:"+str(now)[:16])
                input("Press [Enter] to continue")
                return mainmenu()
        else:
            if int(all_admin[0][2])<=int(str(now)[11:13])<int(all_admin[0][3]):
                pass
            else:
                print("Sorry John, you can only access during "+all_admin[0][2]+":00 - "+all_admin[0][3]+":00")
                print("Current time:"+str(now)[:16])
                input("Press [Enter] to continue")
                return mainmenu()
    for line in all_admin:
        if name == line[0]:
            password = input("Enter password:")
            if password == line[1]:
                print("")
                print("--Log in Successful--")
                return admin_access(name)
            else:
                print("--Password incorrect--")
                return mainmenu()
    print("")
    print("--You are not admin--")
    return mainmenu()

def admin_access(admin):
    print("")
    print("")
    welword="Welcome,"+admin+"!"
    print(welword.center(80))
    print("="*80)
    print("")
    if admin=="John":
        while True:
            print("Press".ljust(40).center(80))
            print("[1]-Tenants manage".ljust(40).center(80))
            print("[2]-Apartment manage".ljust(40).center(80))
            print("[3]-Tenant check-in".ljust(40).center(80))
            print("[4]-Tenant check-out".ljust(40).center(80))
            print("[5]-View rental history".ljust(40).center(80))
            print("[6]-Edit login password".ljust(40).center(80))
            print("[7]-Log out".ljust(40).center(80))
            usertype = input("                    Your choice:")
            if usertype in ["1","2","3","4","5","6","7"]:
                if usertype == "6":
                    print("Your current password:",all_admin[0][1])
                    newpass1=input("Enter your new password:")
                    newpass2=input("Enter again to confirm your new password::")
                    print("")
                    if newpass1=="" and newpass2=="":
                        print("--Can`t be empty--")
                    elif newpass1 == newpass2:
                        print("--Password changed--")
                        all_admin[0][1]=newpass1
                        print(all_admin[0][1])
                    else:
                        print("--Password not confirmed--")
                break
            print("")
            print("{invalid input}".center(80))
            print("")
    elif admin=="David":
        while True:
            print("Press".ljust(40).center(80))
            print("[1]-Tenants manage".ljust(40).center(80))
            print("[2]-Apartment manage".ljust(40).center(80))
            print("[3]-Tenant check-in".ljust(40).center(80))
            print("[4]-Tenant check-out".ljust(40).center(80))
            print("[5]-View rental history".ljust(40).center(80))
            print("[6]-Edit login password".ljust(40).center(80))
            print("[7]-Log out".ljust(40).center(80))
            print("[9]-Change the available access time of John".ljust(40).center(80))
            usertype = input("                    Your choice:")
            if usertype in ["1","2","3","4","5","6","7","9"]:
                if usertype == "6":
                    print("Your current password:",all_admin[1][1])
                    newpass1=input("Enter your new password:")
                    newpass2=input("Enter again to confirm your new password::")
                    print("")
                    if newpass1=="" and newpass2=="":
                        print("--Can`t be empty--")
                    elif newpass1 == newpass2:
                        print("--Password changed--")
                        all_admin[1][1]=newpass1
                        print(all_admin[1][1])
                    else:
                        print("--Password not confirmed--")
                break
            else:
                print("")
                print("{invalid input}".center(80))
                print("")
    if usertype == "1":
        return tenant_manager(admin)
    elif usertype == "2":
        return apartment_manager(admin)
    elif usertype == "3":
        check_in()
        return admin_access(admin)
    elif usertype == "4":
        check_out()
        return admin_access(admin)
    elif usertype == "5":
        view_rental_history()
        return admin_access(admin)
    elif usertype == "6":
        return admin_access(admin)
    elif usertype == "7":
        print("")
        print("--Logged out from Admin Access System--")
        return mainmenu()
    elif usertype == "9":
        start_time=input("Enter the start time(0-23):")
        if start_time.isnumeric()==True:
            start_time=int(start_time)
            if start_time in range(0,24):
                end_time=input("Enter the end time(0-23):")
                if end_time.isnumeric()==True:
                    end_time=int(end_time)
                    if end_time in range(0,24):
                        if start_time!=end_time:
                            all_admin[0][2]=str(start_time)
                            all_admin[0][3]=str(end_time)
                        else:
                            print("--end time can`t be same with start time--")
                    else:
                        print("--Value must be in 0-23--")
                else:
                    print("--Value must be in 0-23--")
            else:
                print("--Value must be in 0-23--")
        else:
            print("--Value must be in 0-23--")
        return admin_access(admin)

def default_user(): 
    print("")
    print("")
    print("Default User".center(60))
    print("-" * 60)
    while True:
        print("Press:".ljust(40).center(80))
        print("[1]-View all Tenents".ljust(40).center(80))
        print("[2]-View all Apartment".ljust(40).center(80))
        print("[3]-View rental history".ljust(40).center(80))
        print("[4]-back to Main Menu".ljust(40).center(80))
        usertype = input("                    Enter your choice:")
        if usertype in ["1","2","3","4"]:
            break
        print("")
        print("--{invalid input}--".center(80))
    if usertype == "1":
        return tenant_manager("default")
    elif usertype == "2":
        return apartment_manager("default")
    elif usertype == "3":
        view_rental_history()
        return default_user()
    elif usertype == "4":
        return mainmenu()

##----------------------------------------------------------------------------------------------------------------------------------------------
##Tenants and apartment manager(Interface)
##----------------------------------------------------------------------------------------------------------------------------------------------
def tenant_manager(admin):
    print("")
    print("")
    show_all_tenants()
    print("--<Tenants Manager>--".center(60))
    print("-" * 60)
    if admin=="John":
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Tenant Info".ljust(40).center(80))
            print("[2]-Add a new Tenent".ljust(40).center(80))
            print("[3]-Edit a Tenant Info".ljust(40).center(80))
            print("[4]-Delete a tenant from system".ljust(40).center(80))
            print("[5]-Back to admin menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","2","3","4","5"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    elif admin=="David":
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Tenant Info".ljust(40).center(80))
            print("[2]-Add a new Tenent".ljust(40).center(80))
            print("[5]-Back to admin menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","2","5"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    else:
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Tenant Info".ljust(40).center(80))
            print("[6]-Back to main menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","6"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    if usertype == "1":
        search_tenant()
        return tenant_manager(admin)
    elif usertype == "2":
        add_tenants()
        return tenant_manager(admin)
    elif usertype == "3":
        edit_tenants()
        return tenant_manager(admin)
    elif usertype == "4":
        delete_tenants()
        return tenant_manager(admin)
    elif usertype == "5":
        return admin_access(admin)
    elif usertype == "6":
        return default_user()
    
def apartment_manager(admin):
    print("")
    print("")
    show_all_apartments()
    print("--<Apartment Manager>--".center(60))
    print("-" * 60)
    if admin=="John":
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Apartment Info".ljust(40).center(80))
            print("[2]-Add a new Apartment Info".ljust(40).center(80))
            print("[3]-Edit a Apartment Info".ljust(40).center(80))
            print("[4]-Delete a Apartment from system".ljust(40).center(80))
            print("[5]-Back to admin menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","2","3","4","5"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    elif admin=="David":
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Apartment Info".ljust(40).center(80))
            print("[2]-Add a new Apartment Info".ljust(40).center(80))
            print("[5]-Back to admin menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","2","5"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    else:
        while True:
            print("Press:".ljust(40).center(80))
            print("[1]-View a Apartment Info".ljust(40).center(80))
            print("[6]-Back to main menu".ljust(40).center(80))
            usertype = input("                    Enter your choice:")
            if usertype in ["1","6"]:
                break
            print("")
            print("--{invalid input}--".center(80))
    if usertype == "1":
        search_apartment()
        return apartment_manager(admin)
    elif usertype == "2":
        add_apartment()
        return apartment_manager(admin)
    elif usertype == "3":
        edit_apartment()
        return apartment_manager(admin)
    elif usertype == "4":
        delete_apartments()
        return apartment_manager(admin)
    elif usertype == "5":
        return admin_access(admin)
    elif usertype == "6":
        return default_user()
##----------------------------------------------------------------------------------------------------------------------------------------------
##Search/Add/Edit/Delete   Tenants/Apartment   (Functions)
##Check-in Check-out        (Functions)
##View rental history       (Function)
##----------------------------------------------------------------------------------------------------------------------------------------------
def search_tenant():
    while True:
        TN_ID=input("Enter the tenant ID :TN")
        if TN_ID.isnumeric()==True:
            count=0
            found=-1
            for tenant in all_tenant:
                if int(TN_ID)==int(tenant[0][2:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<Tenant TN"+TN_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Name                            :"+all_tenant[found][1])
                print("Apartment stay             :"+all_tenant[found][2])
                print("Age                               :"+all_tenant[found][3])
                print("Gender                         :"+all_tenant[found][4])
                print("Birth place                    :"+all_tenant[found][5])
                print("Last job                         :"+all_tenant[found][6])
                print("Current employee name:"+all_tenant[found][7])
                print("Current job                   :"+all_tenant[found][8])
                print("Salary per month           :"+all_tenant[found][9])
                print("----------------------------------------------------------------")
                print("Press [Enter] to continue")
                input()
            else:
                print("Tenant not found")
            return
        else:
            print("Please enter number only")

def add_tenants():
    print("")
    print("<Add a new Tenant>".center(30))
    print("-"*30)
    new_TN_ID=""
    if len(all_tenant)==0:
        new_TN_ID="TN"+str(len(all_tenant)+1)
    else:
        ID_num=1
        for tenant in all_tenant:
            if tenant[0]=="TN"+str(ID_num):
                ID_num+=1
                new_TN_ID="TN"+str(ID_num)
            else:
                new_TN_ID="TN"+str(ID_num)
                break
    while True:
        new_TN_name= input("Enter the Name of tenant:")
        if new_TN_name == "":
            print("--can`t be empty--")
        else:
            new_TN_name=new_TN_name.split(" ")
            for each in new_TN_name:
                if len(each)>1:
                    each=each[0].upper()+each[1:]
                elif len(each)==1:
                    each=each.upper()
            new_TN_name=" ".join(new_TN_name)
            break
    new_rent_ID="Not renting any apartment"
    while True:
        new_TN_age = input("Enter the age of the tenants:")
        if new_TN_age.isnumeric():
            new_TN_age = int(new_TN_age)
            if new_TN_age < 18 or new_TN_age > 150:
                print("--Not Illegal age(18-150)--")
            else:
                new_TN_age = str(new_TN_age)
                break
        else:
            print("--please enter age number--")
    while True:
        print("Choose the  gender of the tenant:")
        print("[m]-Male")
        print("[f]-Female")
        print("[o]-Other")
        new_TN_gender=input("Your choice:")
        if new_TN_gender in ["m","f","o"]:
            if new_TN_gender=="m":
                new_TN_gender="Male"
            elif new_TN_gender=="f":
                new_TN_gender="Female"
            elif new_TN_gender=="o":
                new_TN_gender="Other"
            break
        else:
            print("--please choose in 'm','f','o'--")
    while True:
        new_TN_country= input("Enter the birth country of the tenant:")
        if new_TN_country == "":
            print("--can`t be empty--")
        else:
            break
    while True:
        new_TN_city= input("Enter the birth city of the tenant:")
        if new_TN_city == "":
            print("--can`t be empty--")
        else:
            break
    new_TN_birthplace=new_TN_city+","+new_TN_country
    new_TN_lastjob= input("Enter the last job of the tenant:")
    new_TN_currentjob= input("Enter the current job of the tenant:")
    new_TN_currentemployee= input("Enter the current employee name of the tenant:")
    while True:
        new_TN_salary = input("Enter the salary per month of the tenants:RM")
        if new_TN_salary.isnumeric():
            new_TN_salary = int(new_TN_salary)
            if new_TN_salary < 0:
                print("--Can`t be negatif number--")
            else:
                new_TN_salary = "RM"+str(new_TN_salary)
                break
        else:
            print("--please enter number--")
    new_TN=[new_TN_ID,new_TN_name,new_rent_ID,new_TN_age,new_TN_gender,new_TN_birthplace,new_TN_lastjob,new_TN_currentjob,new_TN_currentemployee,new_TN_salary]
    all_tenant.append(new_TN)
    print("")
    print("")
    print("--New tenant added--")


def edit_tenants():
    while True:
        TN_ID=input("Enter the tenant ID to edit:TN")
        if TN_ID.isnumeric()==True:
            count=0
            found=-1
            for tenant in all_tenant:
                if int(TN_ID)==int(tenant[0][2:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<Tenant TN"+TN_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Name                            :"+all_tenant[found][1])
                print("Apartment stay             :"+all_tenant[found][2])
                print("Age                               :"+all_tenant[found][3])
                print("Gender                         :"+all_tenant[found][4])
                print("Birth place                    :"+all_tenant[found][5])
                print("Last job                         :"+all_tenant[found][6])
                print("Current employee name:"+all_tenant[found][7])
                print("Current job                   :"+all_tenant[found][8])
                print("Salary per month           :"+all_tenant[found][9])
                print("----------------------------------------------------------------")
                print("Press to change:")
                print("[1]-Last Job")
                print("[2]-Current employee name")
                print("[3]-Current job")
                print("[4]-Salary per month")
                print("[5]-Cancel edit")
                while True:
                    choice=input("Enter your choice:")
                    if choice=="1":
                        new_TN_lastjob= input("Enter the last job of the tenant:")
                        all_tenant[found][6]=new_TN_lastjob
                        print("Change Successful")
                        return
                    elif choice=="2":
                        new_TN_currentjob= input("Enter the current job of the tenant:")
                        all_tenant[found][7]=new_TN_currentjob
                        print("Change Successful")
                        return
                    elif choice=="3":
                        new_TN_currentemployee= input("Enter the current employee name of the tenant:")
                        all_tenant[found][8]=new_TN_currentemployee
                        print("Change Successful")
                        return
                    elif choice=="4":
                        while True:
                            new_TN_salary = input("Enter the salary per month of the tenants:RM")
                            if new_TN_salary.isnumeric():
                                new_TN_salary = int(new_TN_salary)
                                if new_TN_salary < 0:
                                    print("--Can`t be negatif number--")
                                else:
                                    all_tenant[found][9]= "RM"+str(new_TN_salary)
                                    print("Change Successful")
                                    return
                    elif choice=="5":
                        return
                    else:
                        print("--Invalid Input--")
            else:
                print("Tenant not found")
                return
        else:
            print("Please enter number only")

def delete_tenants():
    while True:
        TN_ID=input("Enter the tenant ID to edit:TN")
        if TN_ID.isnumeric()==True:
            count=0
            found=-1
            for tenant in all_tenant:
                if int(TN_ID)==int(tenant[0][2:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<Tenant TN"+TN_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Name                            :"+all_tenant[found][1])
                print("Apartment stay             :"+all_tenant[found][2])
                print("Age                               :"+all_tenant[found][3])
                print("Gender                         :"+all_tenant[found][4])
                print("Birth place                    :"+all_tenant[found][5])
                print("Last job                         :"+all_tenant[found][6])
                print("Current employee name:"+all_tenant[found][7])
                print("Current job                   :"+all_tenant[found][8])
                print("Salary per month           :"+all_tenant[found][9])
                print("----------------------------------------------------------------")
                if all_tenant[found][2]!="Not renting any apartment":
                    print("This tenant is staying in apartment:"+all_tenant[found][2])
                    print("You can`t delete this tenant")
                    print("Press [Enter] to continue")
                    input()
                    return
                print("Confirm to delete?")
                print("[1]-Yes")
                print("[2]-No")
                while True:
                    choice=input("Enter your choice:")
                    if choice=="1":
                        all_tenant.remove(all_tenant[found])
                        print("Tenant "+TN_ID+" deleted")
                        return
                    elif choice=="2":
                        print("Request canceled")
                        return
                    else:
                        print("--Invalid Input--")
            else:
                print("Tenant not found")
                return
        else:
            print("Please enter number only")

def show_all_tenants():
    print("")
    print("<All tenants` Info>".center(106,"-"))
    print("TN ID           |Name            |Status          |age             |gender          |salary per month")
    print("-"*106)
    for tenant in all_tenant:
        less=tenant[:5]
        less.append(tenant[9])
        for each in less:
            print(each.ljust(16),end="")
            symbol="|"
            print(symbol,end="")
        print("")
    print("-"*106)

def search_apartment():
    while True:
        APM_ID=input("Enter the tenant ID to edit:APM")
        if APM_ID.isnumeric()==True:
            count=0
            found=-1
            for apartment in all_apartment:
                if int(APM_ID)==int(apartment[0][3:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<APM"+APM_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Tenant in this apartment:"+all_apartment[found][1])
                print("Floor                             :"+all_apartment[found][2])
                print("Date of acquire             :"+all_apartment[found][3])
                print("Square Footage              :"+all_apartment[found][4])
                print("Expected tental             :"+all_apartment[found][5])
                print("----------------------------------------------------------------")
                print("Press [Enter] to continue")
                input()
            else:
                print("Apartment not found")
            return
        else:
            print("Please enter number only")

def add_apartment():
    print("")
    print("<Add a new Apartment>".center(30))
    print("-"*30)
    if len(all_apartment)==0:
        new_APM_ID="APM"+str(len(all_apartment)+1)
    else:
        ID_num=1
        for apartment in all_apartment:
            if apartment[0]=="APM"+str(ID_num):
                ID_num+=1
                new_APM_ID="APM"+str(ID_num)
            else:
                new_APM_ID="APM"+str(ID_num)
                break
    new_APM_status= "Available for rent"
    while True:
        new_APM_floor = input("Enter which floor the apartment at:")
        if new_APM_floor.isnumeric():
            if 0<int(new_APM_floor) <= 10:
                new_APM_floor="F"+new_APM_floor
                break
            else:
                print("--Only in Floor 1 to 10--")
        else:
            print("--please enter floor number--")
    new_APM_dateacquire=str(now)[:10]
    while True:
        new_APM_square= input("Enter the square feet of the apartment:")
        if new_APM_square.isnumeric():
            if int(new_APM_square)>0:
                new_APM_square=new_APM_square+"m/square"
                break
            else:
                print("can`t be zero")
        else:
            print("Please enter numbers only")
    while True:
        new_APM_expectedrent= input("Enter the expected rent of the apartment:RM")
        if new_APM_expectedrent.isnumeric():
            if int(new_APM_expectedrent)>0:
                new_APM_expectedrent="RM"+new_APM_expectedrent
                break
            else:
                print("can`t be zero")
        else:
            print("Please enter numbers only")
    new_APM=[new_APM_ID,new_APM_status,new_APM_floor,new_APM_dateacquire,new_APM_square,new_APM_expectedrent]
    all_apartment.append(new_APM)
    print("")
    print("")
    print("--New apartment added--")

def edit_apartment():
    while True:
        APM_ID=input("Enter the apartment ID to edit:APM")
        if APM_ID.isnumeric()==True:
            count=0
            found=-1
            for apartment in all_apartment:
                if int(APM_ID)==int(apartment[0][3:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<APM"+APM_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Tenant in this apartment:"+all_apartment[found][1])
                print("Floor                             :"+all_apartment[found][2])
                print("Date of acquire             :"+all_apartment[found][3])
                print("Square Footage              :"+all_apartment[found][4])
                print("Expected tental             :"+all_apartment[found][5])
                print("----------------------------------------------------------------")
                print("Press to change:")
                print("[1]-Expected tental")
                print("[2]-Cancel edit")
                while True:
                    choice=input("Enter your choice:")
                    if choice=="1":
                        while True:
                            new_APM_expectedrent= input("Enter the expected rent of the apartment:RM")
                            if new_APM_expectedrent.isnumeric():
                                if int(new_APM_expectedrent)>0:
                                    new_APM_expectedrent="RM"+new_APM_expectedrent
                                    all_apartment[found][5]=new_APM_expectedrent
                                    print("Change Successful")
                                    return
                                else:
                                    print("can`t be zero")
                            else:
                                print("Please enter numbers only")
                    elif choice=="2":
                        return
                    else:
                        print("--Invalid Input--")
            else:
                print("Apartment not found")
                return
        else:
            print("Please enter number only")

def delete_apartments():
    while True:
        APM_ID=input("Enter the apartment ID to edit:APM")
        if APM_ID.isnumeric()==True:
            count=0
            found=-1
            for apartment in all_apartment:
                if int(APM_ID)==int(apartment[0][3:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<APM"+APM_ID+"`s Info>")
                print("----------------------------------------------------------------")
                print("Tenant in this apartment:"+all_apartment[found][1])
                print("Floor                             :"+all_apartment[found][2])
                print("Date of acquire             :"+all_apartment[found][3])
                print("Square Footage              :"+all_apartment[found][4])
                print("Expected tental             :"+all_apartment[found][5])
                print("----------------------------------------------------------------")
                if all_apartment[found][1]!="Available for rent":
                    print("This apartment is having tenant:"+all_apartment[found][1])
                    print("You can`t delete this apartment")
                    print("Press [Enter] to continue")
                    input()
                    return
                print("Confirm to delete?")
                print("[1]-Yes")
                print("[2]-No")
                while True:
                    choice=input("Enter your choice:")
                    if choice=="1":
                        all_apartment.remove(all_apartment[found])
                        print("Apartment "+APM_ID+" deleted")
                        return
                    elif choice=="2":
                        print("Request canceled")
                        return
                    else:
                        print("--Invalid Input--")
            else:
                print("Apartment not found")
                return
        else:
            print("Please enter number only")


def show_all_apartments():
    print("")
    print("<All apartment Info>".center(126,"-"))
    print("   ID               |Status              |Floor               |Date of acquire     |Square Footage      |Expected Rent")
    print("-"*126)
    for apartment in all_apartment:
        for each in apartment:
            print(each.ljust(21),end="")
            symbol="|"
            print(symbol,end="")
        print("")
    print("-"*126)

def check_in():
    print("")
    print("<Check in registration>".center(30))
    print("-"*30)
    while True:
        TN_ID=input("Enter the check-in tenant`s ID:TN")
        if TN_ID.isnumeric()==True:
            count=0
            found=-1
            for tenant in all_tenant:
                if int(TN_ID)==int(tenant[0][2:]):
                    found=count
                count+=1
            if found!=-1:
                if all_tenant[found][2]=="Not renting any apartment":
                    checkin_TN="TN"+TN_ID
                    break
                else:
                    print("Tenant TN"+TN_ID+" already live in "+all_tenant[found][2])
                    return
            else:
                print("Tenant not found")
                return
        else:
            print("Please enter number only")
    while True:
        APM_ID=input("Enter the check-in apartment`s ID:APM")
        if APM_ID.isnumeric()==True:
            count=0
            found=-1
            for apartment in all_apartment:
                if int(APM_ID)==int(apartment[0][3:]):
                    found=count
                count+=1
            if found!=-1:
                if all_apartment[found][1]=="Available for rent":
                    checkin_APM="APM"+APM_ID
                else:
                    print("Apartment APM"+APM_ID+" already rented by "+all_apartment[found][1])
                    return
            else:
                print("Apartment not found")
                return
        else:
            print("Please enter number only")
        print("Check-in confrimation")
        print("----------------------------")
        print("Check-in tenant ID:"+checkin_TN)
        print("Check-in apartment ID:"+checkin_APM)
        print("Check-in date:"+str(now)[:10])
        print("----------------------------")
        print("Press:")
        print("[1]-Yes")
        print("[2]-No")
        while True:
            choice=input("Enter your choice:")
            if choice=="1":
                break
            elif choice=="2":
                print("Check in canceled")
                return
            else:
                print("Invalid Input")
        new_checkin=[checkin_TN,checkin_APM,str(now)[:10],"-"]
        all_history.append(new_checkin)
        #Change tenans.txt status
        count=0
        for tenant in all_tenant:
            if tenant[0]==checkin_TN:
                break
            count+=1
        all_tenant[count][2]=checkin_APM
        #Change apartment.txt status
        count=0
        for apartment in all_apartment:
            if apartment[0]==checkin_APM:
                break
            count+=1
        all_apartment[count][1]=checkin_TN
        print("Check-in successful")
        return
    

def check_out():
    while True:
        TN_ID=input("Enter the tenant ID to check-out:TN")
        if TN_ID.isnumeric()==True:
            count=0
            found=-1
            for tenant in all_tenant:
                if int(TN_ID)==int(tenant[0][2:]):
                    found=count
                count+=1
            if found!=-1:
                print("")
                print("<Tenant TN"+TN_ID+">")
                print("----------------------------------------------------------------")
                print("Name                       :"+all_tenant[found][1])
                print("Check-out apartment:"+all_tenant[found][2])
                print("----------------------------------------------------------------")
                if all_tenant[found][2]=="Not renting any apartment":
                    print("This tenant is not renting any apartment")
                    input("Press [Enter] to continue")
                    return
                print("Check-out confirmation")
                print("[1]-Yes")
                print("[2]-No")
                while True:
                    choice=input("Enter your choice:")
                    if choice=="1":
                        #Change rent-historytxt
                        count=-1
                        for history in all_history:
                            count+=1
                            print(history[0],all_tenant[found][2])
                            print(history[1][2:],TN_ID)
                            print(history[3])
                            if history[0]==TN_ID and history[1][3:]==all_tenant[found][2] and  history[3]=="-":
                                break
                        all_history[count][3]=str(now)[:10]
                        #Change tenants.txt status
                        count=-1
                        for tenant in all_tenant:
                            count+=1
                            if tenant[0][2:]==TN_ID:
                                break
                        all_tenant[count][2]="Not renting any apartment"
                        #Change apartment.txt status
                        count=-1
                        for apartment in all_apartment:
                            count+=1
                            if apartment[0]==all_tenant[found][2]:
                                break
                        all_apartment[count][1]="Available for rent"
                        print("")
                        print("Check-out successful")
                        return
                    elif choice=="2":
                        print("")
                        print("Check-out canceled")
                        return
                    else:
                        print("--Invalid Input--")
            else:
                print("Tenant not found")
                return
        else:
            print("Please enter number only")

def view_rental_history():
    print("")
    print("<All rental history>".center(70,"-"))
    print("   APM ID   |   TN ID    |Check-in date|Check-out date")
    print("-"*70)
    for history in all_history:
        for each in history:
            print(each.ljust(12),end="")
            symbol="|"
            print(symbol,end="")
        print("")
    print("-"*70)
    print("Press [Enter] to continue")
    input()
    

##----------------------------------------------------------------------------------------------------------------------------------------------
##Main flow
##----------------------------------------------------------------------------------------------------------------------------------------------
def main():
    print("Welcome to Tenant Management System".center(80))
    print("Press [Enter] to start".center(80))
    input()
    try:
        for lines in open("tenants.txt","r").readlines():
            lines=lines.strip().split(";")
            all_tenant.append(lines)
        for lines in open("apartment.txt","r").readlines():
            lines=lines.strip().split(";")
            all_apartment.append(lines)
        for lines in open("rent-history.txt","r").readlines():
            lines=lines.strip().split(";")
            all_history.append(lines)
        for lines in open("admins.txt","r").readlines():
            lines=lines.strip().split(";")
            all_admin.append(lines)
    except:
        open("tenants.txt","w").write("")
        open("apartment.txt","w").write("")
        open("rent-history.txt","w").write("")
        open("admins.txt","w").write("John;123;20;22\nDavid;456")
        for lines in open("tenants.txt","r").readlines():
            lines=lines.strip().split(";")
            all_tenant.append(lines)
        for lines in open("apartment.txt","r").readlines():
            lines=lines.strip().split(";")
            all_apartment.append(lines)
        for lines in open("rent-history.txt","r").readlines():
            lines=lines.strip().split(";")
            all_history.append(lines)
        for lines in open("admins.txt","r").readlines():
            lines=lines.strip().split(";")
            all_admin.append(lines)
            
    mainmenu()

    #Sort according ID before write back
    for a in range(len(all_tenant)):
        for b in range(len(all_tenant)):
            if int(all_tenant[a][0][2:])<int(all_tenant[b][0][2:]):
                all_tenant[a],all_tenant[b]=all_tenant[b],all_tenant[a]
    with open("tenants.txt","w") as wr:
        for lines in all_tenant:
            lines=";".join(lines)+"\n"
            wr.write(lines)
        wr.close()
    #Sort according ID before write back
    for a in range(len(all_apartment)):
        for b in range(len(all_apartment)):
            if int(all_apartment[a][0][3:])<int(all_apartment[b][0][3:]):
                all_apartment[a],all_apartment[b]=all_apartment[b],all_apartment[a]
    with open("apartment.txt","w") as wr:
        for lines in all_apartment:
            lines=";".join(lines)+"\n"
            wr.write(lines)
        wr.close()
    with open("rent-history.txt","w") as wr:
        for lines in all_history:
            lines=";".join(lines)+"\n"
            wr.write(lines)
        wr.close()
    with open("admins.txt","w") as wr:
        for lines in all_admin:
            lines=";".join(lines)+"\n"
            wr.write(lines)
        wr.close()

main()
